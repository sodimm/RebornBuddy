using System;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Threading;
using ff14bot;
using ff14bot.AClasses;
using ff14bot.Behavior;
using ff14bot.Helpers;
using ICSharpCode.SharpZipLib.Zip;
using TreeSharp;
using Action = System.Action;

namespace ArtemisLoader
{
    public class ArtemisLoader : BotBase
    {
        private const string PROJECT_NAME = "Artemis";
        private const string PROJECT_MAIN_TYPE = "Artemis.Artemis";
        private const string PROJECT_ASSEMBLY_NAME = "Artemis.dll";
        private const string VERSION_URL = "https://github.com/sodimm/RebornBuddy/blob/master/BotBases/Artemis/version.txt?raw=true";
        private const string DATA_URL = "https://github.com/sodimm/RebornBuddy/blob/master/BotBases/Artemis/Artemis.zip?raw=true";
        private static readonly Color _logColor = Color.FromRgb(183, 73, 91);
        public override PulseFlags PulseFlags => PulseFlags.All;
        public override bool IsAutonomous => true;
        public override bool WantButton => true;
        public override bool RequiresProfile => false;

        private static readonly object _locker = new object();
        private static readonly string _versionPath = Path.Combine(Environment.CurrentDirectory, $@"BotBases\{PROJECT_NAME}\version.txt");
        private static readonly string _projectAssembly = Path.Combine(Environment.CurrentDirectory, $@"BotBases\{PROJECT_NAME}\{PROJECT_ASSEMBLY_NAME}");
        private static readonly string _greyMagicAssembly = Path.Combine(Environment.CurrentDirectory, @"GreyMagic.dll");
        private static readonly string _projectDir = Path.Combine(Environment.CurrentDirectory, $@"BotBases\{PROJECT_NAME}");
        private static readonly string _projectTypeFolder = Path.Combine(Environment.CurrentDirectory, @"BotBases");
        private static bool _updated;
        private static Composite _root;
        private static Action _onButtonPress, _start, _stop;

        private static readonly Composite _failsafeRoot = new TreeSharp.Action(c =>
        {
            Log($"{PROJECT_NAME} is not loaded correctly.");
            TreeRoot.Stop();
        });

        public ArtemisLoader()
        {
            lock (_locker)
            {
                if (_updated) { return; }
                _updated = true;
            }

            var dispatcher = Dispatcher.CurrentDispatcher;
            Task.Run(async () => { await Update(); Load(dispatcher); });
        }

        public override string Name => PROJECT_NAME;

        public override Composite Root => _root ?? _failsafeRoot;

        public override void OnButtonPress() => _onButtonPress?.Invoke();

        public override void Start() => _start?.Invoke();

        public override void Stop() => _stop?.Invoke();

        private static void Load(Dispatcher dispatcher)
        {
            RedirectAssembly();

            var assembly = LoadAssembly(_projectAssembly);
            if (assembly == null) { return; }

            Type baseType;
            try { baseType = assembly.GetType(PROJECT_MAIN_TYPE); }
            catch (Exception e)
            {
                Log(e.ToString());
                return;
            }

            dispatcher.BeginInvoke(new Action(() =>
            {
                object product;
                try { product = Activator.CreateInstance(baseType); }
                catch (Exception e)
                {
                    Log(e.ToString());
                    return;
                }

                if (product == null)
                {
                    Log("[Error] Could not load main type.");
                    return;
                }

                var type = product.GetType();
                _root = (Composite)type.GetProperty("Root")?.GetValue(product);
                _start = (Action)type.GetProperty("StartAction")?.GetValue(product);
                _stop = (Action)type.GetProperty("StopAction")?.GetValue(product);
                _onButtonPress = (Action)type.GetProperty("ButtonAction")?.GetValue(product);

                Log($"{PROJECT_NAME} loaded.");
            }));
        }

        public static void RedirectAssembly()
        {
            ResolveEventHandler handler = (sender, args) =>
            {
                string name = Assembly.GetEntryAssembly().GetName().Name;
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != name ? null : Assembly.GetEntryAssembly();
            };

            AppDomain.CurrentDomain.AssemblyResolve += handler;

            ResolveEventHandler greyMagicHandler = (sender, args) =>
            {
                var requestedAssembly = new AssemblyName(args.Name);
                return requestedAssembly.Name != "GreyMagic" ? null : Assembly.LoadFrom(_greyMagicAssembly);
            };

            AppDomain.CurrentDomain.AssemblyResolve += greyMagicHandler;
        }

        private static Assembly LoadAssembly(string path)
        {
            if (!File.Exists(path)) { return null; }

            Assembly assembly = null;
            try { assembly = Assembly.LoadFrom(path); }
            catch (Exception e) { Logging.WriteException(e); }

            return assembly;
        }

        private static async Task Update()
        {
            var local = GetLocalVersion();
            var data = await TryUpdate(local);
            if (data == null) { return; }

            try { Clean(_projectDir); }
            catch (Exception e) { Log(e.ToString()); }

            try { Extract(data, _projectTypeFolder); }
            catch (Exception e) { Log(e.ToString()); }
        }

        private static void Extract(byte[] files, string directory)
        {
            using (var stream = new MemoryStream(files))
            {
                var zip = new FastZip();
                zip.ExtractZip(stream, directory, FastZip.Overwrite.Always, null, null, null, false, true);
            }
        }

        private static void Clean(string directory)
        {
            foreach (var file in new DirectoryInfo(directory).GetFiles())
            {
                file.Delete();
            }

            foreach (var dir in new DirectoryInfo(directory).GetDirectories())
            {
                dir.Delete(true);
            }
        }

        private static void Log(string message)
        {
            message = $"[{PROJECT_NAME}] {message}";
            Logging.Write(_logColor, message);
        }

        private static string GetLocalVersion()
        {
            if (!File.Exists(_versionPath)) { return null; }
            try
            {
                var version = File.ReadAllText(_versionPath);
                return version;
            }
            catch { return null; }
        }

        public static async Task<byte[]> TryUpdate(string localVersion)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    var stopwatch = Stopwatch.StartNew();
                    var version = await client.GetStringAsync(VERSION_URL);
                    if (string.IsNullOrEmpty(version) || version == localVersion) { return null; }

                    Log($"Local: {localVersion} | Latest: {version}");
                    using (var response = await client.GetAsync(DATA_URL))
                    {
                        if (!response.IsSuccessStatusCode)
                        {
                            Log($"[Error] Could not download {PROJECT_NAME}: {response.StatusCode}");
                            return null;
                        }

                        using (var inputStream = await response.Content.ReadAsStreamAsync())
                        using (var memoryStream = new MemoryStream())
                        {
                            await inputStream.CopyToAsync(memoryStream);

                            stopwatch.Stop();
                            Log($"Download took {stopwatch.ElapsedMilliseconds} ms.");

                            return memoryStream.ToArray();
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Log($"[Error] {e}");
                return null;
            }
        }
    }
}
